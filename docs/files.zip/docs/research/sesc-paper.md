## SESC Simulator
***
#### The feature of SESC
* SESC is easy for extension. SESC is written in a modular fashion to facilitate extend additional architectures upon the given package. SESC also provides a configurable cache system, which is easy to reconfigure and extend.
* 
